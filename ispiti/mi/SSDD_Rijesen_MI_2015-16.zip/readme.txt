u 1.b) fali paleta na x5, pripaziti da je na ispitu ispravljana linija I u II
u 2.b) je prvi A slučajno indeksiran
3. možda ima više točnih rješenja ovisno o definiciji automata
