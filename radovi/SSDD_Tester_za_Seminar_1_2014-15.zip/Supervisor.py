# popuni poslove kao u uputama za labos
v = { };
v['red'] = [ (10, 11), (11, 14), (14, 10) ]
v['green'] = [ (10, 14), (14, 11), (11, 8), (8, 7), (7, 5), (5, 1), (1, 4), (4, 10) ]
v['blue'] = [ (1, 2), (2, 6), (6, 9), (9, 13), (13, 14), (14, 13), (13, 9), (9, 6), (6, 2), (2, 1) ]


class State():
	def __init__(self):
		self.vs = { 'red': [0]*len(v['red']), 'green': [0]*len(v['green']), 'blue': [0]*len(v['blue']) }
		self.vc = { 'red': [0]*len(v['red']), 'green': [0]*len(v['green']), 'blue': [0]*len(v['blue']) }
	def start_timer(self,color):
		pass
	def check_timer(self):
		pass


class Supervisor():
	def __init__(self,state,trains,turnout_ctrl):
		self.state = State()
		self.vc_time = { 'red': [], 'green': [], 'blue': [] }
		self.vs_time = { 'red': [], 'green': [], 'blue': [] }
		self.tag = { }
	def translate(self,color):
		pass