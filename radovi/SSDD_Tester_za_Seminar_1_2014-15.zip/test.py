import sys
import time
del time

cur_time = 0

def time():
	return cur_time

time_h = sys.modules['time']
time_h.time = time	
	
from mySupervisor_template import mySupervisor
from Supervisor import v

ssdd = mySupervisor(0,0,0)

cost = { (10,14):7, (14,10): 7, (14,11):7, (11,14):7, (10,11): 14, (11,8) : 5, (8,7): 3, (7,5) :5, (5,1): 7, (1,4):7, (4,10):12,  (14,13):3, (13,14): 3, (13,9): 5, (9,13) : 5, (9,6): 14, (6,9): 14, (6,2): 5, (2,6): 5, (2,1): 3, (1,2) : 3 }


ssdd.first_scan = True
ssdd.new_scan()

eventqueue = [ ]

while(1):
	print "Time: ", time()
	for i in range(len(eventqueue)):
		if cur_time == eventqueue[i][2]:
			ssdd.state.vc[eventqueue[i][3]][eventqueue[i][4]] = 1
			print "Event happened:", eventqueue[i][3], (eventqueue[i][0], eventqueue[i][1])
			# todo: remove from queue
			
	ssdd.new_scan()
	for k in ssdd.state.vs:
		for i in range(len(ssdd.state.vs[k])):
			if ssdd.state.vs[k][i] == 1:
				print "Starting event:",k, v[k][i]
				eventqueue.append(v[k][i]+(cur_time+cost[v[k][i]],k,i))
				ssdd.state.vs[k][i] = 0
				ssdd.state.vc[k] = [0]*len(v[k])
				#start,fin,timefin,color,index
	#print eventqueue
	#ssdd.state.vc = { 'red': [0]*3, 'green': [0]*8, 'blue': [0]*10 }
	
	#print ssdd.vc_time
	
	raw_input("Press Enter to continue...")
	cur_time += 1
			